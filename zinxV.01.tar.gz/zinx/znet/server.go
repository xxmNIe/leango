package znet

import (
	"fmt"
	"io"
	"leango/zinx/ziface"
	"net"
)

type Server struct {
	Name string
	IPVersion string
	IP string
	Port int

}

func (s *Server) Start(){

	go func() {
		//获取tcp的addr
		fmt.Printf("[start]  Server Listenner at ip: %s,port: %d, staring\n",s.IP,s.Port)
		taddr,err := net.ResolveTCPAddr("tcp",fmt.Sprintf("%s:%d",s.IP,s.Port))
		if err !=nil{
			fmt.Println("resolve tcp addr err: ",err )
		}

		//监听服务器地址
		listener,err := net.ListenTCP(s.IPVersion,taddr)
		if err !=nil{
			fmt.Println("listen tcp addr err: ",err )
		}
		fmt.Println("start Server ",s.Name," succ")

		//等待客户端链接,处理
		for{
			conn ,err := listener.AcceptTCP()
			if err !=nil{
				fmt.Println("accept err: ",err)
			}

			fmt.Println(" handler conn ",conn.RemoteAddr())

			go func() {
				for {
					buf :=make([]byte,512)
					cnt,err := conn.Read(buf)
					if err!=nil{
						if err ==io.EOF{
							fmt.Println("read EOF")
							break
						}
						fmt.Println("recv err :",err)
						continue
					}
					if _,err = conn.Write(buf[:cnt]);err!=nil{
						fmt.Println("write err ",err)
						continue
					}
				}
			}()

		}
	}()

}
func (s *Server) Stop(){

}
func (s *Server) Server(){
	s.Start()


	select {

	}
}


func NewServer(name string) ziface.IServer {
	s:= &Server{
		Name: name,
		IPVersion: "tcp4",
		IP: "0.0.0.0",
		Port: 8999,
	}
	return s
}