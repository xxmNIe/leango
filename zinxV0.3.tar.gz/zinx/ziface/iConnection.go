package ziface

import "net"

type IConnection interface {
	Start()
	Stop()

	GetConnection() *net.TCPConn

	GetConnID() uint32

	RemoteAddr() net.Addr

	Send([]byte ) error

}
//
type  HandleFunc func(*net.TCPConn,[]byte,int ) error