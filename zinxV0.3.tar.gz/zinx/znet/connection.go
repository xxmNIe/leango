package znet

import (
	"fmt"
	"io"
	"leango/zinx/ziface"
	"net"
)

type Connection struct {
	Conn *net.TCPConn

	ConnID uint32

	isClosed bool

	ExitChan chan bool

	//该链接处理方法
	Router ziface.IRouter
}

func (c *Connection)Start(){
	fmt.Println("Conn start() ... ConnID = ",c.ConnID)
	//启动从当链接读取数据的业务

	go c.StartReader()




}
func (c *Connection)Stop(){

	fmt.Println("Conn Sttop(),,, ConnID=",c.ConnID)
	if c.isClosed==true{
		return
	}
	c.isClosed = true
	close(c.ExitChan)
	
}

func (c *Connection)GetConnection() *net.TCPConn{
	return c.Conn
}

func (c *Connection)GetConnID() uint32{
	return  c.ConnID
}

func (c *Connection)RemoteAddr() net.Addr{
	addr := c.Conn.RemoteAddr()
	return addr
}

func (* Connection)Send([]byte ) error{
	return nil
}

//链接的读业务
func (c *Connection) StartReader() {
	fmt.Println("Reader Goroutine is running")
	cl:= c.RemoteAddr().String()
	defer fmt.Println("Conn=",c.ConnID," Reader is exit,remote addr is ",cl)
	defer c.Stop()

	for{
		buf := make([]byte,512)
		_,err :=c.Conn.Read(buf)
		if err!=nil{
			if err ==io.EOF{
				break
			}
			fmt.Println("recv buf err ",err)
			continue
		}

		req :=Request{
			conn: c,
			data: buf,
		}

		//从路由中 找到注册绑定的Con你对应的router调用
		go func(req ziface.IRequest) {
			c.Router.PreHandle(req)
			c.Router.Handle(req)
			c.Router.PostHandle(req)
		}(&req)

		//TODO 这里的问题   interface 类型必须传指针？
		//c.Router.PreHandle(req)

	}
}

func NewConnection(conn *net.TCPConn,connID uint32,router ziface.IRouter) *Connection{
	c := &Connection{
		Conn: conn,
		ConnID: connID,
		Router: router,
		isClosed: false,
		ExitChan: make(chan bool,1),
	}

	return c
}