package znet

import (
	"fmt"
	"leango/zinx/ziface"
	"net"

)

type Server struct {
	Name string
	IPVersion string
	IP string
	Port int
	//当前server添加一个router，注册链接对应的处理业务
	Router ziface.IRouter

}
func (s *Server)AddRouter(router ziface.IRouter){
	s.Router = router
	fmt.Println("Add Router Succ")
}



func (s *Server) Start(){

	go func() {
		//获取tcp的addr
		fmt.Printf("[start]  Server Listenner at ip: %s,port: %d, staring\n",s.IP,s.Port)
		taddr,err := net.ResolveTCPAddr("tcp",fmt.Sprintf("%s:%d",s.IP,s.Port))
		if err !=nil{
			fmt.Println("resolve tcp addr err: ",err )
		}

		//监听服务器地址
		listener,err := net.ListenTCP(s.IPVersion,taddr)
		if err !=nil{
			fmt.Println("listen tcp addr err: ",err )
		}
		fmt.Println("start Server ",s.Name," succ")

		var cid uint32
		cid = 0
		//等待客户端链接,处理
		for{
			conn ,err := listener.AcceptTCP()
			if err !=nil{
				fmt.Println("accept err: ",err)
			}
			fmt.Println(" handler conn ",conn.RemoteAddr())

			c:= NewConnection(conn,cid,s.Router)
			go c.Start()
		}
	}()

}
func (s *Server) Stop(){

}
func (s *Server) Server(){
	s.Start()


	select {

	}
}

//func CallBack(conn *net.TCPConn,buf []byte,ctn int ) error {
//	fmt.Println("CallBack .....")
//	if _,err := conn.Write(buf);err!=nil{
//		fmt.Println("call back weite err:",err)
//	}
//	return nil
//}

func NewServer(name string) ziface.IServer {
	s:= &Server{
		Name: name,
		IPVersion: "tcp4",
		IP: "0.0.0.0",
		Port: 8999,
		Router: nil,
	}
	return s
}