package znet

import (
	"fmt"
	"leango/zinx/utils"
	"leango/zinx/ziface"
	"net"

)

type Server struct {
	Name string
	IPVersion string
	IP string
	Port int
	//当前server的消息管理模块,用来绑定msgId和对应的处理业务
	MsgHandler ziface.IMsgHandler

}
func (s *Server)AddRouter(msgID uint32,router ziface.IRouter){
	s.MsgHandler.AddRouter(msgID,router)
	fmt.Println("Add Router Succ")
}



func (s *Server) Start(){
	fmt.Printf("[Zinx] Server name :%s listenner at Ip:%s port:%d is starting \n",utils.GlobalObject.Name,utils.GlobalObject.Host,utils.GlobalObject.TcpPort)
	fmt.Printf("[Zinx] MaxConn %d,MaxPackageSize:%d\n",utils.GlobalObject.MaxConn,utils.GlobalObject.MaxPackageSize)
	go func() {
		taddr,err := net.ResolveTCPAddr("tcp",fmt.Sprintf("%s:%d",s.IP,s.Port))
		if err !=nil{
			fmt.Println("resolve tcp addr err: ",err )
		}

		//监听服务器地址
		listener,err := net.ListenTCP(s.IPVersion,taddr)
		if err !=nil{
			fmt.Println("listen tcp addr err: ",err )
		}
		fmt.Println("start Server ",s.Name," succ")

		var cid uint32
		cid = 0
		//等待客户端链接,处理
		for{
			conn ,err := listener.AcceptTCP()
			if err !=nil{
				fmt.Println("accept err: ",err)
			}
			fmt.Println(" handler conn ",conn.RemoteAddr())
			//这里把router与conn绑定,所以要在server.server()调用之前添加router
			c:= NewConnection(conn,cid,s.MsgHandler)
			go c.Start()
		}
	}()

}
func (s *Server) Stop(){

}
func (s *Server) Server(){
	s.Start()


	select {

	}
}

//func CallBack(conn *net.TCPConn,buf []byte,ctn int ) error {
//	fmt.Println("CallBack .....")
//	if _,err := conn.Write(buf);err!=nil{
//		fmt.Println("call back weite err:",err)
//	}
//	return nil
//}

func NewServer(name string) ziface.IServer {
	s:= &Server{
		Name: utils.GlobalObject.Name,
		IPVersion: "tcp4",
		IP: utils.GlobalObject.Host,
		Port: utils.GlobalObject.TcpPort,
		MsgHandler: NewMshHandle(),
	}
	return s
}